$(".navbar-brand").click(function(){
   $(this).fadeOut(200).fadeIn(200);
   
})